---
title: Pendulum
...

![Figure 1: Shot of Pendulum Setup](imgs/ShotofPendulum.jpg)

## INTRODUCTION

:::GVideo
1pIzodfE9WJOX1i7c8YtBO6uIZQluBJoO 
:::

## PART 1: WHAT'S IMPORTANT?

The objective of this lab is to determine the physical quantities which influence the period of a pendulum. The period is how long it takes to make one complete cycle of motion. The relevant features are the mass of the bob, the length of the pendulum, and the initial angular displacement. We will test each of these features separately by varying one of them while keeping the other two constant.

You will be expected to turn in all plots and table you are asked to make in an exercise, and answers to question.

<!-- Mass Constant -->
::: Exercise

Let's start by varying the mass and keeping the initial angle and the length constant.

For our pendulum setup we have five different masses that we can put at the end of our pendulum. Below is a video showing each one being massed. Watch this video to determine the mass of each of the five masses. Throughout this lab, we will use the same numbering scheme for each mass as presented in this video so when we say "Mass 4" in a later video we are talking about the same mass presented here.

<!-- Measuring Mass -->
:::GVideo
108sTERiCeJOJ92uHeAm9B-exfOxGMwhf
:::

1. Make a table with each of the mass names and its mass. Pause the video and use the triple beam balance to make your best measurement of the mass. You will be adding columns to this table shortly.

In the next video you will be shown 5 different pendulum setups swinging. The only thing that is different among the five setups is the mass that is used. The initial angle for each setup is $20^{\circ}$, and the length is 80 cm.

<!-- 5 Masses All 20 Degrees-->
:::GVideo
1lqcS_DnxxwiNgmr2UiTGGXjgzSz_pP0P
:::

2. For each mass, using the stopwatch in the video, a stopwatch app, or the video timestamp record 5 complete periods. A complete period is the time it takes for the pendulum to swing back and forth. Then divide this number by five to obtain an average time for one period. Record these data in a new column in your table.

:::Question
Does the period depend on mass? Justify you answer.
:::

:::

<!-- Angle Vary -->
::: Exercise

In this exercise we will now vary the initial angle while keeping the length and mass constant.

Conventional analysis of the pendulum is done for small angles, where the restoring force experienced by the mass is approximately linear with the displacement angle. Linear restoring force is one of the criteria for simple harmonic motion. When the displacement angles become large, the restoring force is no longer linear. The motion is still periodic, but it is not sinusoidal, and the mathematical analysis becomes far more involved.

You will be working with only a single mass for this part of the experiment. You will choose you mass based on your birthday. Below is table with links to the video of pendulums with different masses. Select the video based on the month in which you were born. **Make sure to write down which mass you are using so that we can grade properly.**

<!-- Angle Shots  -->
- Jan-Mar: [Mass 1](https://drive.google.com/file/d/12WEhapaNaXc6JPnEOBocNOOJHpTGhFL1/preview){target="_blank"}
- Apr-May: [Mass 2](https://drive.google.com/file/d/1eDohP1HnzRAsPvc0WbQn28EiH66KAm8j/preview){target="_blank"}
- Jun-Jul: [Mass 3](https://drive.google.com/file/d/1NEYJZgXHIncCZ-Xyd3CYg4CyI1g_aYgZ/preview){target="_blank"}
- Aug-Sep: [Mass 4](https://drive.google.com/file/d/19_nc3NRZklMWOmDlw3Mu5X8qWLChLeKI/preview){target="_blank"}
- Oct-Dec: [Mass 5](https://drive.google.com/file/d/1yzMxyhSi5UIQu9iX2edyHTIjXrWBoP6U/preview){target="_blank"}

In this video you'll see a pendulum starting at the different initial angles of $5^{\circ}$, $10^{\circ}$, $15^{\circ}$, and $20^{\circ}$. The mass and the length will stay constant. You will collect your data from this.

1. Make a new data table where you will record the period for each initial angle.

2. Use the same method as in Exercise 1 to measure the period.

::: Question
a. Does period depend upon the initial angular displacement? Justify your answer.
b. Why do you need to use only one mass instead of all five to justify this?
:::

::: <!-- End Angle Exercise -->

<!-- Varying Length -->
::: Exercise
In this exercise we will vary length while keeping mass and initial angle constant.

Again, you will work only with one mass based on your birthday. **Make sure to write down which mass you are using so that we can grade properly.**

<!-- Length Varying Videos -->
- Jan-Mar: [Mass 1](https://drive.google.com/file/d/1TtMf7UfRCKhXu134eaH91VVEdBsu16Ue/preview){target="_blank"}
- Apr-May: [Mass 2](https://drive.google.com/file/d/1Or7pUcM8OmnONFpDRKK5-OdIGyvH-Ws8/preview){target="_blank"}
- Jun-Jul: [Mass 3](https://drive.google.com/file/d/17kvfPVy2iOZzQwUnwWRVnTwFcw1RnApd/preview){target="_blank"}
- Aug-Sep: [Mass 4](https://drive.google.com/file/d/1zpFcqpQezpDVB3oWN3UgChLTZn9D0qTD/preview){target="_blank"}
- Oct-Dec: [Mass 5](https://drive.google.com/file/d/1cgXZBTHO-ZrjDlPDKBFX5t13Ctm76cOx/preview){target="_blank"}

In the video you will see 3 pendulum setups all using the same mass and initial angle of $10^{\circ}. The only thing varying among runs in the length. After each run, there will be a close-up of the mass with a meterstick in the background. You can use this to make your own length measurement.

1. Build a new data table that will contain the data for the lengths and the periods for each run.

2. Use the same method as in Exercise 1 to measure the period. Pause the video after each run then measure and record the length. 

::: Question
a) Does the period depend upon the length? Justify your answer.
:::

::: <!-- End Length Exercise -->

## PART 2: DETERMINING THE MATHEMATICAL DEPENDENCE

We will restrict our analysis to small angles. You should have found that the most significant factor influencing the period was the length of the pendulum. We would now like to figure out what the mathematical relationship is.

::: Exercise
In this exercise we have designed an experiment to investigate the relationship between length and period.

Below is a video of several pendulum setups using mass 4. The initial angles are all $10^{\circ}$. We will vary the length from about 76 cm to 22 cm. You will be making period measurements for each length. This time you can use the lengths given.

:::GVideo
1wdoOshvovKF1sE89l3Cz-4hM-DYJY9xB
:::

1. Make a data table that has the length and period for each run.
2. Make a plot of period vs length.

::: Question
a) Describe the relationship between length and period.
b) What type of trendline both fits the data and makes sense?
:::

:::



## PART 3: LOG-LOG GRAPHING TUTORIAL

::: Exercise

1. Consider the simple linear relationship $y = 3x$. Make a table of x and y values for values of $x = 1,2,3,4,5$. Leave room in the table for more calculations.

2. Next to this, make another table, this time record the $log_{10}(x)$, and the $log_{10}(y)$. Plot the value of $log_{10}(x)$ on the independent axis. Plot the value of $log_{10}(y)$ on the dependent axis.

::: Question
a. What is the slope of this line, and why is it significant?
b. What is the y-intercept? What is the inverse $log(10^{x})$ of this value, and why is it significant?
:::

:::

::: Exercise

1. Consider the non-linear relationship $y = 4x^{3}$. Again make a table of x and y values for values of $x = 1,2,3,4,5$. Add two columns to the table, this time recording $log_{10(x)}$, and $log_{10}(y)$. Plot the value of $log_{10}(x)$ on the independent axis. Plot the value of $log_{10}(y)$ on the dependent axis.

::: Question
a. What is the slope of this line and what does it represent?
b. What is the y-intercept? What is the antilog of this value and why is it important?
:::

2. Taking the logarithm of both sides changes $$y = 4x^{3}$$ into $$Log_{10}(y) = Log_{10}(4x^{3})$$

::: Question
a. Use the logarithm property
$Log_{10}(ab) = Log_{10}(a) + Log_{10}(b)$ to reduce the right hand side of this relationship. Explain how this relates to the y-intercept on your graph.
:::


3. Now use the logarithm property $Log_{10}(a^{b}) = bLog_{10}(a)$ to further reduce the right hand side.


::: Question
a. Show this math. Explain how this relates to the slope of your graph. Hint: Your graph has an independent variable of "$Log_{10}(x)$", not "$x$."
b. Consider the relationship $y = x^{1/3}$ If you made a log-log plot of this, what would the slope be?
:::

:::

## PART 4: ANALYZING NON-LINEAR DATA

::: Exercise

1. Using the data from Part 2, make a table of $Log_{10}(Length)$ and $Log_{10}(Period)$. Plot $Log_{10}(Length)$ on the independent axis, $Log_{10}(Period)$ on the dependent axis. **Hint: Convert length measurements to meters.**

::: Question
a) What is the value of slope of this line? What is its significance?
b) What is the y-intercept of this line?
c) Knowing what you know now, does this agree with your response to Question 4.a? Why?
:::

The relationship between the period and length can be expressed:

$$period = 2𝜋 \left (\frac{Length}{a} \right )^b$$

where $a$ and $b$ are unknown values.

2. Start with the equation given above. Take the logarithm of both sides, and reduce this equation using the logarithmic properties listed above. SHOW THIS WORK.

In your final reduction, you should recognize that some values are constant, while one term is dependent upon Length (specifically the $Log_{10}(Length)$).

3.  Using the slope and y-intercept of your Log-Log graph, determine the quantities $a$ and $b$.

::: Question
a. What is the value of $b$ and what does it tell you about the relationship between period and length?
b. What is the value of $a$ and what does it suggest? **Hint: Think of quantities which are physically relevant to the experiment.**
c. Using dimensional analysis, show that this interpretation of $a$ makes sense.
d. What is the explicit mathematical relationship between Period and Length?
:::

:::

## PART 5: POST LAB

::: Question
a) Consider two pendulums with masses that are equal, but different shape, both tied to the same length of string. The first is a sphere, similar to those used in this experiment. The second is a lengthy rod, tied at one end. Which pendulum has a longer period? **Hint: Think about the center of mass and what that means for the effective length.**
:::

For the next few questions, use the PhET simulation for a pendulum:

![Simulation 1](https://ilg-physics-ucsb.github.io/PhETMods/pendulum-lab/pendulum-lab_en.html?screens=1){width=100% height=600px}

::: Question
a. Spend some time recreating the experiment using the PhET simulation. Do you find similar results? What are some notable differences, if any? **Hint: consider the friction setting!**

b. How would you expect the period of the pendulum to change as you increase and decrease the friction? Also would you expect friction to arise in a natural setting?

c. Using the PhET simulation for a pendulum, consider a pendulum on Planet X. How could you determine what the acceleration due to gravity, $g_x$, on Planet X is? Using your method, what is the value of $g_x$

d. What are the two possible sources of friction in the experiment? **(Hint: Points of contact and the medium in which the experiment is set up.)**
:::

:::Exercise
Write a brief conclusion summarizing the important points of this lab.
:::

